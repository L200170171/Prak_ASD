def rerata(b):
    x=sum(b)/len(b)
    print(x)

x=[2,3,6,5]
rerata(x)