for i in range(1,100):
    if ((i%3)==0) and ((i%5)==0):
        print("python ums")
    elif (i%3) == 0 :
        print("python")
    elif (i%5) == 0 :
        print("UMS")
    else:
        print(i)