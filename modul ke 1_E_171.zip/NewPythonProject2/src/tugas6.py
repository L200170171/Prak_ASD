for i in range (2,1000):
    d=2
    while i%d!=0:
        if d==(i-1):
            print (i," ",d)
        d=d+1
print("selesai")