def cetaksiku(x):
    i=1
    while i<=x:
        print("*"*i)
        i+=1
cetaksiku(5)