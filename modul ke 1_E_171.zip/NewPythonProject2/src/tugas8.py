def apakah(a,b):
    if a in b:
        print("True")
    else:
        print("False")

a="halo do"
b="katakan halo dora"

apakah(a,b)